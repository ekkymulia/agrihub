package com.example.agrihubandro.components.fragments;

import androidx.lifecycle.ViewModel;

public class FilterViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}