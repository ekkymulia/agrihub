package com.example.agrihubandro.components.rv_tempt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.agrihubandro.R;

public class ProductImageList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_image_list);
    }
}