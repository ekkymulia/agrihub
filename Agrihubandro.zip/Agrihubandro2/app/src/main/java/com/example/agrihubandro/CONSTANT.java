package com.example.agrihubandro;

public class CONSTANT {
    public static final String BASE_URL = "http://10.0.2.2:8000";
    public static final String IMG_BASE_URL = "http://192.168.137.134:8000";

//    public static final String BASE_URL = "http://192.168.137.134:8000";
}

