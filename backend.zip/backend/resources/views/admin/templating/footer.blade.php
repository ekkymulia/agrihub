<footer class="main-footer font-xs">
    <div class="row pb-30 pt-15">
        <div class="col-sm-6">
            <script>
                document.write(new Date().getFullYear());
            </script>
            &copy; Agrihub.
        </div>
        <div class="col-sm-6">
            <div class="text-sm-end">All rights reserved</div>
        </div>
    </div>
</footer>